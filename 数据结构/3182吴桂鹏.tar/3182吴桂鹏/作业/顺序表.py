class SeqList(object):
    # 初始化顺序表
    def __init__(self):
        self.SL = []


    #判断是否为空
    def kong(self):
        if not self.SL:
            print("顺序表为空")
        else:
            print("顺序表不为空")

    #添加元素
    def CreateSequenceList(self):
        Element = int(input("输入元素:"))
        while Element != '#':
            self.SL.append(int(Element))
            Element = input('输入元素:')

    #输出元素的个数
    def SequenceListLen(self):
        print("顺序表中一共有", len(self.SL), "个元素")

    #获取SL中元素5的位置
    def SequenceListIndex(self):
        key = int(input("输入要查找的元素"))
        ipos = self.SL.index(key)
        print("元素", key, "的位置是", ipos)

    #插入元素
    def InsertElement(self):
        key = int(input("要插入元素的位置"))
        values = int(input("要插入的元素"))
        self.SL.insert(key, values)
        print("插入元素后， 当前顺序表为：\n", self.SL)

    #删除元素
    def DeleteElement(self):
        dPos = int(input("要删除的元素的位置"))
        print("正在删除", self.SL[dPos], '...')
        self.SL.remove(self.SL[dPos])
        print("删除后的顺序表为:\n", self.SL)

    #排序
    def SortSequenceList(self):
        self.SL.sort()
        print("升序", self.SL)
        self.SL.sort(reverse=True)
        print("降序", self.SL)

    def SetSequenceList(self):
        print("删除重复元素", list(set(self.SL)))

    def zhuan(self):
        print("转置", self.SL[::-1])
    #销毁
    def __del__(self):
        print('销毁')


if __name__ == '__main__':
    sl = SeqList()
    sl.kong()
    sl.CreateSequenceList()
    sl.SequenceListLen()
    sl.SequenceListIndex()
    sl.InsertElement()
    sl.DeleteElement()
    sl.SetSequenceList()
    sl.zhuan()
