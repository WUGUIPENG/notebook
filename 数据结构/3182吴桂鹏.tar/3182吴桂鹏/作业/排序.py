from random import randrange, shuffle

def Bubblesort():
    array = []

    while len(array) < 12:  # 范围内随机取12个数值
        array.append(randrange(-99, 101, 3))
    shuffle(array)  # 打乱数组

    print('排序前数组：{}'.format(array))
    sum = 0
    for i in range(12):
        for j in range(11 - i):
            if array[j] > array[j + 1]:  # 遇到较小值前后交换
                array[j], array[j + 1] = array[j + 1], array[j]
                print('第{}排序:{}'.format(sum,array))
                sum += 1

    print('排序后数组：{}'.format(array))

Bubblesort()