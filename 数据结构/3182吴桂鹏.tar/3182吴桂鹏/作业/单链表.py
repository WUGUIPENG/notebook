#单链表
class Node(object):
    def __init__(self, data): #构造函数初始化
        self.data = data
        self.next = None



class SingleLinkedList(object):
    def __init__(self):            #构造函数初始化头节点
        self.head = Node(None)

    # 创建单链表
    def CreateLinkedList(self):
        Conde = self.head          #获取头节点
        Element = input("请输入数据:")
        while Element != '#':
            nNode = Node(int(Element))
            Conde.next = nNode    #头指针指向第一个元素
            Conde = Conde.next    #给第一个元素一个指针， 这个指针指向下一个元素
            Element = input("请输入数据:")

    #遍历单链表
    def TreveresElement(self):
        Conde = self.head   #指向头节点
        if Conde.next == None:
            print("当前链表为空！")
            return
        print("当前链表为:")
        while Conde != None:
            Conde = Conde.next  #链表不为空则指向下一个指针
            self.visitEment(Conde)

    def visitEment(self, tNode):
        if tNode != None:
            print(tNode.data, "->", end = " ")
        else:
            print('none')

    #插入前节点
    def InsertElementHead(self):
        Element = input("输入要插在头节点的数:")
        while Element == '#':
            return
        cNode = self.head
        nNode = Node(int(Element))
        nNode.next = cNode.next
        cNode.next = nNode


    #插入尾节点
    def InsertElement(self):
        Element = input("输入插入在尾节点的数")
        while Element == '#':
            return
        cNode = self.head
        nNode = Node(int(Element))
        while cNode.next != None:
            cNode = cNode.next
        cNode.next = nNode


    #删除
    def RemoveElement(self):
        Element = int(input("输入要删除的元素"))
        cNode = self.head
        pNode = self.head


        while cNode.next != None and cNode.data != Element:
            pNode = cNode
            cNode = pNode.next
        if cNode.data == Element:
            pNode.next = cNode.next
            del cNode
            print("删除成功！")
        else:
            print("删除失败！")




LinkedList = SingleLinkedList()
LinkedList.CreateLinkedList()
LinkedList.TreveresElement()
LinkedList.InsertElementHead()
LinkedList.TreveresElement()
LinkedList.InsertElement()
LinkedList.TreveresElement()
LinkedList.RemoveElement()
LinkedList.TreveresElement()
