for i in range(10000):
    if (i*i)%(10**len(str(i)))==i:
        print(i)