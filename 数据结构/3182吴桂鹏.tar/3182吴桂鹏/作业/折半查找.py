import random
def bin_search(data, val):
    low = 0
    high = 49

    while low <= high and val != -1:
        mid = int((low+high)/2)
        if val < data[mid]:
            print('%d 介于 %d[%3d] 和中间值 %d[%3d] 之间, 找左半边' %(val, low+1, data[low], mid+1, data[mid]))
            high=mid-1
        elif val > data[mid]:
            print('%d 介于 %d[%3d] 和中间值 %d[%3d] 之间, 找右半边' %(val, mid+1, data[mid], high+1, data[high]))
            low=mid+1
        else:
            return mid
    return -1
val = 