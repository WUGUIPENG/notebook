#定义一个节点
#分别有元素data， 指向下一个节点的指针next
class QueueNode:
    def __init__(self):
        self.data = None
        self.next = None

#定义一个链式队列
#提供链式队列的相关操作
class LinkQueue:
    #默认初始化队列的函数
    def __init__(self):
        tQueueNode = QueueNode()
        self.front = tQueueNode
        self.rear = tQueueNode

    #判断队列是否为空的函数
    def IsEmptyQueue(self):
        if self.front == self.rear:
            iQueue = True
        else:
            iQueue = False
        return iQueue

    #入队
    #主要操作是：创建一个新节点， 将其链接到队列的末尾， 并由rear指向它
    def EnQueue(self, data):
        tQueueNode = QueueNode() #入队前创建新节点
        tQueueNode.data = data #新节点添加元素
        self.rear.next = tQueueNode #将next指向新创建的节点
        self.rear = tQueueNode #将rear指针指向新节点
        print('当前入队元素为：',data)

    #出队
    #1,判断队列是否为空，队列为空无法出队
