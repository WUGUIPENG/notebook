count = 0
for a in range(1, 6):
    for b in range(1, 6):
        if a!= b:
            for c in range(1, 6):
                if a != c and c != b:
                    count +=1
print(count)