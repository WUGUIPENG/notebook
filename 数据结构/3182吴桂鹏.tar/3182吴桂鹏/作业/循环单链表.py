#循环单链表
class Node(object):
    def __init__(self, data): #构造函数初始化
        self.data = data
        self.next = None


class SingleLinkedList(object):
    def __init__(self):            #构造函数初始化头节点
        self.head = Node(None)

    # 创建单链表
    def CreateLinkedList(self):
        Conde = self.head          #获取头节点
        Element = input("请输入数据:")
        while Element != '#':
            nNode = Node(int(Element))
            Conde.next = nNode    #头指针指向第一个元素
            nNode.next = self.head #最后一个元素始终指向头节点
            Conde = Conde.next    #给第一个元素一个指针， 这个指针指向下一个元素
            Element = input("请输入数据:")
