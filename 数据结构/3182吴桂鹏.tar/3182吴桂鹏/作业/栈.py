class SequenceStack(object):
    def __init__(self):
        self.MaxStackSize = 10
        self.s = [None for x in range(0, self.MaxStackSize)]
        self.top = -1    #空栈的top为-1

    #输出但前栈的长度
    def GetStackLength(self):
        if self.IsEmptyStack():  #判断栈是否为空
            print("栈为空")
            return
        else:
            return self.top+1

    #判断栈是否为空函数
    def IsEmptyStack(self):
        if self.top == -1:
            itop = True
        else:
            itop = False


    #通过输入元素创建一个栈
    def CreateStackByInput(self):
        data = input('请输入元素，以#结束输入：')
        while data != '#':
            self.PushStack(data)
            data = input('请输入元素， 以#结束输入')

    #入栈
    def PushStack(self, data):
        if self.top < self.MaxStackSize-1:
            self.top = self.top+1
            self.s[self.top]=data
        else:
            print('栈满')
            return


    #出栈
    def PopStack(self):
        if self.IsEmptyStack():
            print('栈空')
            return
        else:
            itop = self.top
            self.top -= 1
            return self.s[self.top]

    #遍历栈内元素
    def StackTraverse(self):
        if self.IsEmptyStack():
            print('栈空')
            return
        else:
            for i in range(0,  self.top+1):
                print(self.s[i], end = ' ')


ss = SequenceStack()
ss.CreateStackByInput()
ss.StackTraverse()
ss.PopStack()
ss.StackTraverse()