val = 0
data = [12,15,32,43,56,77,86,99]
while val !=  -1:
    find = 0
    val = int(input('输入:'))
    for i in range(8):
        if data[i] == val:
            print('第%3d个位置 [%3d]' %(i, data[i]))
            find += 1

    if find == 0 and val != -1:
        print('没有找到[%3s]' %val)

print('数据内容为:')
for i in range(4):
    for j in range(2):
        print('%2d[%3d] ' %(i*8+j+1, data[i*8+j]), end='')
    print(' ')