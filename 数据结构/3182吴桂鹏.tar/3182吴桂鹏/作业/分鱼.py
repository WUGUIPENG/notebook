fish = 1
flag = 1
while flag:
    total = fish
    for n in range(4):
        if (total-1)%5==0 and total%4==0:
            total = total//4*5+1
            if n==3:
                print(fish)
                print(total)
                flag =0
    fish += 1
