# 初始化栈
class LinkStack:
    def __init__(self):
        self.top = StackNone()


# 初始化节点
class StackNone(LinkStack):
    def __init__(self):
        self.data = None
        self.next = None

    def CreateSrackByInput(self):
        data = input("请输入元素， 以#结束")
        while data != '#':
            self.PushStack(data)
            data = input("请继续输入元素，以#结束")

    def PushStack(self, x):
        s = StackNone()
        s.data = x
        s.next = self.top.next
        self.top.next = s
        print("当前进栈元素为", x)

    def IsEmptyStack(self):
        if self.top == -1:
            itop = True
        else:
            itop = False

    def Pop(self):
        p = self.top
        self.top = self.top.next
        return p.data

    def StackTraverse(self):
        if self.IsEmptyStack():
            print("栈空")
            return
        else:
            p = self.top
            while p != None:
                print(p.data, end='->')
                p = p.next


ss = StackNone()
ss.CreateSrackByInput()
ss.StackTraverse()
print()
