#队列
class SequenceQueue:
    #默认初始化队列的函数
    def __init__(self):
        self.MaxQueuSize = 10
        self.s = [None for x in range(0, self.MaxQueuSize)]
        self.front = 0
        self.rear = 0
    #判断队列是否为空的函数
    def IsEmptyQueue(self):
        if self.front == self.rear:
            iQueue = True
        else:
            iQueue = False
        return iQueue

    #元素入队的函数

    def EnQueue(self, x):
        if (self.rear+1)%self.MaxQueuSize != self.front:
            self.rear = (self.rear+1)%self.MaxQueuSize
            self.s[self.rear] = x
            print("当前队列元素为:", x)
        else:
            print("队列已满， 无法入队")
            return

    #元素出队函数
    def DeQueue(self):
        if self.IsEmptyQueue():
            print("队列为空， 无法出队")
            return
        else:
            self.front = (self.front + 1)%self.MaxQueuSize
            return self.s[self.front]

    #获当前队首元素的函数
    def GetHead(self):
        if self.IsEmptyQueue():
            print("队列为空， 无法输出首元素")
            return
        else:
            return self.s[self.front + 1] #对头指针指向队首的前一个， 所以加一

    #依次访问队列中元素的函数
    def QueueTraverse(self):
        if self.IsEmptyQueue():
            print("队列为空")
            return
        else:
            for i in range(self.front, self.rear):
                print(self.s[i+1], end=' ')

    #由用户输入元素将其进队的函数
    def CreateQueueByInput(self):
        data = input("请输入元素:")
        while data != '#':
            self.EnQueue(data)
            data = input("请输入元素:")


sq = SequenceQueue()
sq.CreateQueueByInput()
sq.QueueTraverse()